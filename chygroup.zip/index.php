<?php include 'header.php'; ?>

<div class="mainpanel">
    <div class="pageheader">
        <div class="media">
            <div class="pageicon pull-left">
                <i class="fa fa-home"></i>
            </div>
            <div class="media-body">
                <ul class="breadcrumb">
                    <li><a href=""><i class="glyphicon glyphicon-home"></i></a></li>
                    <li>Dashboard</li>
                </ul>
                <h4>Dashboard</h4>
            </div>
        </div><!-- media -->
    </div><!-- pageheader -->

    <div class="contentpanel">

        <div class="row row-stat">
            <CENTER><h1>SELAMAT DATANG</h1>
                    <img src="images/Cahaya Group.jpg" width="300px"></CENTER>
        </div><!-- row -->

    </div><!-- contentpanel -->

</div><!-- mainpanel -->

<?php include "footer.php" ?>

